<!DOCTYPE html>

<html>
    <head>
        <title>Liste Absences</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    </head>
    <body>
    <style type="text/css">
      div.a{
        color: #000000;
        text-align: center;
      }
    </style>
    <div class="a">
    <h1>LISTE D'ABSENCES</h1>
    </div>
</div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" rel="stylesheet"/>
    <nav class="navbar navbar-toggleable-md navbar-light bg-faded">
    
    <ul class="navbar-nav">
    <li class="nav-item dropdown">
    
  </li>
</ul>
</nav>
<style type="text/css">
  
  body{
    background: #3D6B6E;
  }
  
  </style>
  <style type="text/css">
  
  table{
    background: #ffffff;
  }
  
  </style>
<div class="panel body">
                <table class="table table-striped space ">
                        
                        <thead class="space">
                            <th>Matricule</th>
                            <th>Nom</th>
                            <th>Prenom</th>
                            <th>Sexe</th>
                            <th>Date</th>
                            <th>Classe</th>
                            <th>Cours</th>
                        </thead>
                        
                    </table>
            </div>
</body>
</html>