<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


<!Doctype html>
<html>
<head>
     <meta charset="UTF-8">
     <title>Registration Form</title>
     	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<style>

body{
	 background:#3D6B6E;
}

.container{
	font-family:Roboto,sans-serif;
	  background: #ffffff;
     text-align: center;
     margin-top: 67px;
     max-width: 500px;
     padding-top: 10px;
     height: 363px;
     margin-top: 166px;
}
.lastname{
	 margin-left: 1px;
     font-family: sans-serif;
     font-size: 14px;
     color: black;
     margin-top: 10px;
}
.firstname{
	 margin-left: 1px;
     font-family: sans-serif;
     font-size: 14px;
     color: black;
     margin-top: 5px;
}
#lname{
	 margin-top:5px;
}
.heading{
	 text-decoration:bold;
	 text-align : center;
	 font-size:30px;
	 color:#F96;
	 padding-top:10px;
}
#email{
	  margin-top: 5px;
}
.mail{
	 margin-left: 44px;
     font-family: sans-serif;
     color: black;
     font-size: 14px;
     margin-top: 13px;
}
.pass{
	 color: black;
     margin-top: 9px;
     font-size: 14px;
     font-family: sans-serif;
     margin-left: 6px;
     margin-top: 9px;
}
#password{
 margin-top: 6px;
}
.pno{
	 font-size: 18px;
     margin-left: -13px;
     margin-top: 10px;
     color: #ff9;
	
}	
.Sexe {
	 color: black;
     font-family: sans-serif;
     font-size: 14px;
     margin-left: 28px;
     margin-top: 8px;
}
.col-xs-4.male{
	 color: black;
     font-size: 13px;
     margin-top: 9px;
     padding-bottom: 16px;
}
.col-xs-4.female {
     color: black;
     font-size: 13px;
     margin-top: 9px;
     padding-bottom: 16px;
	 padding-right: 95px;
}
	  
</style>
 <div class="container">
 
     <header class="heading"> Register</header><hr></hr>
	
	<div class="row ">
	 
         <div class="col-sm-12">
             <div class="row">
			     <div class="col-xs-4">
          	         <label class="firstname">Nom:</label> </div>
		         <div class="col-xs-8">
		             <input type="text" name="Nom" id="Nom" placeholder="Entrer le nom" class="form-control ">
             </div>
		      </div>
		 </div>
		 
		 
         <div class="col-sm-12">
		     <div class="row">
			     <div class="col-xs-4">
                     <label class="lastname">Prenom:</label></div>
				<div class ="col-xs-8">	 
		             <input type="text" name="Prenom" id="Prenom" placeholder="Entrer le prenom" class="form-control last">
                </div>
		     </div>
		 </div>
     
		 <div class="col-sm-12">
		     <div class="row">
			     <div class="col-xs-4">
		             <label class="mail" >Email :</label></div>
			     <div class="col-xs-8"	>	 
			          <input type="email" name="email"  id="email"placeholder="Enter your email" class="form-control" >
		         </div>
		     </div>
		 </div>
	 
          <div class="col-sm-12">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="pass">Mot de passe:</label></div>
				  <div class="col-xs-8">
			             <input type="Mot de passe" name="Mot de passe" id="Mot de passe" placeholder="Entrer le mot de passe" class="form-control">
				 </div>
          </div>
		  </div>
		  
     
         <div class="col-sm-12">
		     <div class ="row">
                 <div class="col-xs-4 ">
			       <label class="Sexe">Sexe:</label>
				 </div>
			 
			     <div class="col-xs-4 male">	 
				     <input type="radio" name="Sexe"  id="Sexe" value="boy">M</input>
				 </div>
				 
				 <div class="col-xs-4 female">
				     <input type="radio"  name="gender" id="Sexe" value="girl" >F</input>
			     </div>
			
		  	 </div>
		     <div class="col-sm-12">
		         <div class="btn btn-warning">Valider</div>
		   </div>
		 </div>
	 </div>	 
		 		 
		 
</div>

</body>		
</html>
	 
	 