<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html lang="en">
    <head> 
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">

		<!-- Website CSS style -->
		<link rel="stylesheet" type="text/css" href="assets/css/main.css">

		<!-- Website Font style -->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
		
		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>

		<title>Insription</title>
	</head>
	<body>
    <style type="text/css">
  
    body{
        background: #3D6B6E;
    }
  
  </style>
		<div class="container">
			<div class="row main">
				<div class="panel-heading">
	               <div class="panel-title text-center">
	               		<h1 class="title">INSCRIPTION PROFESSEUR</h1>
	               		<hr />
	               	</div>
	            </div> 
				<div class="main-login main-center">
					<form class="form-horizontal" method="post" action="#">
          <div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Matricule</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-qrcode" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="Matricule" id="Matricule"  placeholder="Entrer votre matricule"/>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Nom</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="nom" id="nom"  placeholder="Entrer votre nom"/>
								</div>
							</div>
						</div>
                        <div class="form-group">
							<label for="username" class="cols-sm-2 control-label">Prenom</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="Prenom" id="prenom"  placeholder="Entrer votre prenom"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="email" class="cols-sm-2 control-label">Email</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="email" id="email"  placeholder="Entrer votre Email"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">mot de passe </label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="mot passe" class="form-control" name="mot de passe" id="mot de passe"  placeholder="Entrer votre Password"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Date de naissance</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-clock-o" aria-hidden="true"></i></span>
									<input type="Date de naissance" class="form-control" name="Date de naissance" id="confirm"  placeholder="Entrer votre date de naissance"/>
								</div>
							</div>
						</div>
                        <div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Role</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
									<input type="role" class="form-control" name="role" id="role"  placeholder="entrer votre role"/>
								</div>
							</div>
						</div>
              <div class="form-group">
							<label for="" class="cols-sm-2 control-label">Grade</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-mortar-board" aria-hidden="true"></i></span>
									<input type="Grade" class="form-control" name="Grade" id="Grade"/>
								</div>
							</div>
              <div class="form-group">
							<label for="" class="cols-sm-2 control-label">Classe</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-university" aria-hidden="true"></i></span>
									<input type="Classe" class="form-control" name="Classe" id="Classe"/>
								</div>
							</div>
              <div class="form-group">
							<label for="" class="cols-sm-2 control-label">Modules</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-book" aria-hidden="true"></i></span>
									<input type="Modules" class="form-control" name="Modules" id="Modules"/>
								</div>
							</div>
						</div>
            <div class ="row">
                 <div class="col-xs-4 ">
			       <label class="Sexe">Sexe:</label>
				 </div>
			 
			     <div class="col-xs-4 male">	 
				     <input type="radio" name="Sexe"  id="Sexe" value="boy">M</input>
				 </div>
				 
				 <div class="col-xs-4 female">
				     <input type="radio"  name="gender" id="Sexe" value="girl" >F</input>
			     </div>
			
		  	 </div>
                        <div class="form-group">
							<label for="" class="cols-sm-2 control-label">Avatar</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
									<input type="Avatar" class="form-control" name="Avatar" id="Avatar"/>
								</div>
							</div>
						</div>

						<div class="form-group ">
							<button type="button" class="btn btn-primary btn-lg btn-block login-button">Enregistrer</button>
						</div>
						<div class="login-register">
				            <a href="index.php"></a>
				         </div>
					</form>
				</div>
			</div>
		</div>

		<script type="text/javascript" src="assets/js/bootstrap.js"></script>
	</body>
</html>
